 # Práctica 4
En esta práctica tenemos dos imágenes, la imagen original y la imagen a la que se le aplica el filtro. Tenemos distintos botones con los que aplicar los filtros. Cuando aplicamos cualquier filtro, los deslizadores de los colores desaparecen, para que vuelvan a aparecer hay que pulsar el boton "Colores".

Mejoras aplicadas:
    -Imagen espejo.
    -Ruido.
    -Imagen en negativo.